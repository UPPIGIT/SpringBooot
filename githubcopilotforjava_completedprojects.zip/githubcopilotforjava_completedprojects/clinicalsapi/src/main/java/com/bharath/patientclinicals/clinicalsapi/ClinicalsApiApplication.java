package com.bharath.patientclinicals.clinicalsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicalsApiApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ClinicalsApiApplication.class, args);
    }
    
}
