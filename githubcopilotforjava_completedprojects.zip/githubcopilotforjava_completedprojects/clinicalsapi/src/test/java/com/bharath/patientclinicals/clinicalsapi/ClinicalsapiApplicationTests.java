package com.bharath.patientclinicals.clinicalsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicalsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
