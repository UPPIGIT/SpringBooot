import { Component } from '@angular/core';

@Component({
  selector: 'app-confirmcheckin',
  standalone: true,
  imports: [],
  templateUrl: './confirmcheckin.component.html',
  styleUrl: './confirmcheckin.component.css'
})
export class ConfirmcheckinComponent {

}
